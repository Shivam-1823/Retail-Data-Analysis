-- Data preperation and understanding
select *  from Customer
select * from  prod_cat_info
select * from  Transactions
--Q.1 

select count(*) as total_row from  Customer
union all
select count(*) from  prod_cat_info
union all
select count(*)  from  Transactions

-- Q.2
select  count(a.transaction_id) as TOTAL_TRANSACTIONS 
from Transactions as a
where a.Qty < 0

--Q.3 
select convert(date,a.tran_date,105) as a  from Transactions as a 
select  convert(date,b.dob,105) as b  from customer as b

--Q.4
select datediff(day,'2011-01-25','2014-02-28') as timerange_days,
datediff(month,'2011-01-25','2014-02-28') as timerange_month,
datediff(year,'2011-01-25','2014-02-28') as timerange_year




-- Q.5
select a.prod_cat,a.prod_subcat from prod_cat_info as a
where prod_subcat like '%diy%'

-- DATA ANALYSIS

-- Q.1
SELECT top 1 a.Store_type,COUNT(STORE_TYPE)as channel 
FROM Transactions AS a
group by a.Store_type
order by channel desc

--Q.2
select a.Gender,count(Gender) as cust_Gender 
from Customer as a
group by a.Gender

-- Q.3
select top 1 a.city_code,count(city_code) as customer
from  Customer as a
group by a.city_code
order by customer desc

--Q.4
select prod_cat,count(prod_cat) as subcategory 
from prod_cat_info as a
where prod_cat = 'books'
group by a.prod_cat



--Q.5
select abs(max(a.Qty)) as quantity from Transactions as a


--Q.6
select sum(total_amt) as amount 
from transactions as a
inner join prod_cat_info as b
on a.prod_cat_code = b.prod_cat_code
and a.prod_subcat_code = b.prod_sub_cat_code
where b.prod_cat in ('books' ,'electronics')


--Q.7
select count(customer_id) as customer_count
from Customer where customer_Id in
( 
select cust_id from Transactions
left join Customer on customer_Id = cust_id
where total_amt not like '-%'
group by cust_id
having count(transaction_id) > 10
)

-- Q.8
select sum(total_amt) as amount 
from transactions as a
inner join prod_cat_info as b
on a.prod_cat_code = b.prod_cat_code
and a.prod_subcat_code = b.prod_sub_cat_code 
where b.prod_cat in ('clothing' ,'electronics') and Store_type = 'flagship store'


--Q9
select c.prod_subcat,sum(b.total_amt) as total_revenue
from Customer as a
inner join Transactions as b
on a.customer_Id=b.cust_id
inner join prod_cat_info as c
on b.prod_cat_code=c.prod_cat_code
and b.prod_subcat_code  = c.prod_sub_cat_code
where a.Gender='m' and c.prod_cat='electronics'
group by c.prod_subcat

--Q10 
SELECT TOP 5 B.PROD_SUBCAT, 
SUM(cast(A.TOTAL_AMT as float)) as total_sales, 
 cast (100* round(sum(cast(A.total_amt as float)) / (select sum(cast(A.total_amt as float)) from transactions as A ),2) as int)
 as percent_total_sales,
 cast(100* round(sum(cast(case when a.qty<0 then A.qty end as float))/(select sum(cast(a.qty as float)) from transactions as a where a.qty<0),2) as int)
 as percent_total_returns from transactions as A
 left join prod_cat_info as B
 on a.prod_cat_code=B.prod_cat_code
 and A.prod_subcat_code=B.prod_sub_cat_code
 Group by B.prod_subcat
 order by total_sales desc

 --Q11
SELECT CUST_ID,SUM(TOTAL_AMT) AS NET_TOTAL_REVENUE FROM TRANSACTIONs
WHERE CUST_ID IN 
(SELECT CUSTOMER_ID
FROM CUSTOMER
WHERE DATEDIFF(YEAR,CONVERT(DATE,DOB,103),GETDATE()) BETWEEN 25 AND 35)
AND CONVERT(DATE,tran_date,103) BETWEEN DATEADD(DAY,-30,(SELECT MAX(CONVERT(DATE,tran_date,103)) FROM Transactions)) 
AND (SELECT MAX(CONVERT(DATE,tran_date,103)) FROM TRANSACTIONs)
GROUP BY CUST_ID

--Q12
select top 1 prod_cat,Sum(total_amt) as Value_of_returns from Transactions T1 
Inner join prod_cat_info T2 on t1.prod_cat_code=t2.prod_cat_code and T1.prod_subcat_code=T2.prod_sub_cat_code 
where total_amt<0 and convert(date,tran_date,103) between DATEADD(month,-3,(select max(convert(date,tran_date,103)) from Transactions)) 
and (select max(convert(date,tran_date,103))  from Transactions) 
group by prod_cat 
order by 2 DESC 

--Q13 
select Store_type,sum(total_amt)tot_sales,sum(qty) tot_quan from Transactions
group by Store_type
having sum(total_amt)>=all(select sum(total_amt) from Transactions group by Store_type)
and sum(qty)>=all(select sum(qty) from Transactions
group by Store_type)

--Q14 
SELECT PROD_CAT, AVG(TOTAL_AMT) AS AVERAGE
FROM Transactions as T
INNER JOIN prod_cat_info pci ON t.PROD_CAT_CODE=pci.PROD_CAT_CODE AND PROD_SUB_CAT_CODE=PROD_SUBCAT_CODE
GROUP BY PROD_CAT
HAVING AVG(TOTAL_AMT)> (SELECT AVG(TOTAL_AMT) FROM Transactions) 

--Q15
SELECT PROD_CAT, PROD_SUBCAT, AVG(TOTAL_AMT) AS AVERAGE_REV, SUM(TOTAL_AMT) AS REVENUE
FROM transactions t
INNER JOIN prod_cat_info pci ON t.prod_cat_code=pci.prod_cat_code AND prod_sub_cat_code=PROD_SUBCAT_CODE
WHERE PROD_CAT IN
(
SELECT TOP 5 
PROD_CAT
FROM transactions 
INNER JOIN prod_cat_info ON t.prod_cat_code= pci.prod_cat_code AND prod_sub_cat_code = PROD_SUBCAT_CODE
GROUP BY PROD_CAT
ORDER BY SUM(QTY) DESC
)
GROUP BY PROD_CAT, PROD_SUBCAT 















                                                                                                																							--









